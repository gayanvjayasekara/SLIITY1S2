<?php
// Include the database connection file
require_once("dbConnection.php");

// Fetch data in descending order (latest entry first)
$result = mysqli_query($mysqli, "SELECT * FROM contactus ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>My messages</title>
    <link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
    <h2>Messages</h2>
    <p>
        <a href="add.php" class="report-button">New Message</a>
    </p>

    <div class="card-container">
        <?php
        // Fetch data and display in cards
        while ($res = mysqli_fetch_assoc($result)) {
            echo "<div class='card'>";
            echo "<h3>Name: ".$res['name']."</h3>";
            echo "<p>Email: ".$res['email']."</p>";
            echo "<p>Message: ".$res['message']."</p>";
            echo "<p>Reported On: ".$res['created_at']."</p>";
            echo "<a href=\"edit.php?id=$res[id]\" class='edit-button'>Edit</a>";
            echo "<a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\" class='delete-button'>Delete</a>";
            echo "</div>";
        }
        ?>
    </div>
</body>
</html>
